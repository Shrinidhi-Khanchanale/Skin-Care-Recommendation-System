import rec
x = [1,1,1,1,0,1,0,0,0,1,0,0,0,0,1,0,1,0]
print(rec.recs_essentials(x, None))
print()
print(rec.makeup_recommendation('light to medium','all'))